//! Math detection only. No math parsing, rendering, or conversion is performed.

use std::sync::OnceLock;

use dom_query::Document;
use regex::Regex;

use crate::{Warning, WarningCode, dom};

/// Detect structured math and source LaTeX in the original input document.
/// Template content is included because preprocessing can expose shadow content.
/// Examples inside code/pre and ordinary currency text do not trigger a warning.
pub fn has_math(doc: &Document) -> bool {
    static DELIMITED: OnceLock<Regex> = OnceLock::new();
    static TEX_COMMAND: OnceLock<Regex> = OnceLock::new();
    let delimited = DELIMITED.get_or_init(|| {
        Regex::new(r"(?s)\\\((.+?)\\\)|\\\[(.+?)\\\]|\$\$(.+?)\$\$|\$([^$\n]+)\$")
            .expect("literal regex")
    });
    let nodes = dom::subtree(doc.root());
    let library_present = nodes.iter().any(|node| {
        if !dom::is_html_element(*node, "script") {
            return false;
        }
        let src = node.attr_or("src", "").to_ascii_lowercase();
        if src.contains("mathjax") || src.contains("katex") || src.contains("temml") {
            return true;
        }
        if src.is_empty() {
            let text = node.text().to_ascii_lowercase();
            return text.contains("mathjax")
                || text.contains("katex.render")
                || text.contains("temml.render");
        }
        false
    });
    let tex_command =
        TEX_COMMAND.get_or_init(|| Regex::new(r"\\[A-Za-z]{2,}").expect("literal regex"));
    for node in nodes {
        if node.is_element() {
            let tag = node.node_name().unwrap_or_default().to_ascii_lowercase();
            if tag == "math"
                || tag.starts_with("mjx-")
                || node.attr_or("role", "").eq_ignore_ascii_case("math")
                || [
                    "data-math",
                    "data-latex",
                    "data-tex",
                    "data-mathml",
                    "data-katex",
                ]
                .iter()
                .any(|attribute| node.has_attr(attribute))
                || (tag == "script"
                    && node
                        .attr_or("type", "")
                        .to_ascii_lowercase()
                        .starts_with("math/"))
                || (tag == "annotation"
                    && node
                        .attr_or("encoding", "")
                        .eq_ignore_ascii_case("application/x-tex"))
            {
                return true;
            }
            if node.class().is_some_and(|classes| {
                classes.split_ascii_whitespace().any(|class| {
                    let class = class.to_ascii_lowercase();
                    class.starts_with("mathjax")
                        || class.starts_with("katex")
                        || class.starts_with("mwe-math")
                        || matches!(
                            class.as_str(),
                            "math"
                                | "math-inline"
                                | "math-display"
                                | "latex"
                                | "arithmatex"
                                | "tex-math"
                                | "hurmet-tex"
                        )
                })
            }) {
                return true;
            }
            if tag == "img" {
                let src = node.attr_or("src", "").to_ascii_lowercase();
                if src.contains("%5c") && (src.contains('?') || src.contains("latex")) {
                    return true;
                }
                if tex_command.is_match(&node.attr_or("alt", "")) {
                    return true;
                }
            }
        } else if node.is_text() {
            if node.ancestors_it(None).any(|ancestor| {
                ancestor.node_name().is_some_and(|tag| {
                    matches!(
                        tag.as_ref(),
                        "pre" | "code" | "script" | "style" | "textarea"
                    )
                })
            }) {
                continue;
            }
            let text = node.text();
            for captures in delimited.captures_iter(&text) {
                // Backslash delimiters are unambiguous. Dollar delimiters need
                // TeX structure, or a known math library and a simple variable.
                if captures.get(1).or_else(|| captures.get(2)).is_some() {
                    return true;
                }
                let source = captures
                    .get(3)
                    .or_else(|| captures.get(4))
                    .expect("one math delimiter capture")
                    .as_str()
                    .trim();
                if source.contains(['\\', '_', '^', '{', '}'])
                    || (library_present
                        && !source.is_empty()
                        && !source.contains(char::is_whitespace)
                        && source.chars().any(char::is_alphabetic))
                {
                    return true;
                }
            }
        }
    }
    false
}

/// Return exactly one explicit warning when original input contains math.
pub fn warnings(doc: &Document) -> Vec<Warning> {
    if has_math(doc) {
        vec![Warning {
            code: WarningCode::MathNotSupported,
            message: "Math support is not yet included.".to_owned(),
        }]
    } else {
        Vec::new()
    }
}
