/// Count words with Defuddle's BMP CJK and ASCII whitespace rules.
pub fn count_words(text: &str) -> usize {
    let mut count = 0;
    let mut in_word = false;
    for ch in text.chars() {
        let cjk = matches!(ch as u32,
            0x3040..=0x309f | 0x30a0..=0x30ff | 0x3400..=0x4dbf |
            0x4e00..=0x9fff | 0xf900..=0xfaff | 0xac00..=0xd7af);
        if cjk {
            count += 1;
            in_word = false;
        } else if ch <= ' ' {
            in_word = false;
        } else if !in_word {
            count += 1;
            in_word = true;
        }
    }
    count
}

/// Count visible words with separators between structural blocks. Inline
/// wrappers do not split a word (e.g. `<em>re</em>tain` remains one word).
pub fn count_content_words(root: dom_query::NodeRef<'_>) -> usize {
    let mut text = String::new();
    let mut pending = vec![(root, false)];
    while let Some((node, exit)) = pending.pop() {
        if node.is_text() {
            text.push_str(&node.text());
            continue;
        }
        let name = tag(node);
        let block = crate::constants::BLOCK_LEVEL_ELEMENTS.contains(&name.as_str())
            || matches!(name.as_str(), "br" | "td" | "th" | "dt" | "dd");
        if block {
            text.push(' ')
        }
        if !exit {
            if block {
                pending.push((node, true))
            }
            for child in node.children().into_iter().rev() {
                pending.push((child, false))
            }
        }
    }
    count_words(&text)
}

pub fn normalize_text(text: &str) -> String {
    text.replace('\u{a0}', " ")
        .replace(['\u{2018}', '\u{2019}', '\u{201a}', '\u{201b}'], "'")
        .replace(['\u{2012}', '\u{2013}', '\u{2014}', '\u{2015}'], "-")
        .replace(['\u{201c}', '\u{201d}', '\u{201e}', '\u{201f}'], "\"")
        .replace('\u{2026}', "...")
        .split_whitespace()
        .collect::<Vec<_>>()
        .join(" ")
        .to_lowercase()
}

pub fn tag(node: dom_query::NodeRef<'_>) -> String {
    node.node_name()
        .map(|name| name.to_ascii_lowercase())
        .unwrap_or_default()
}

pub fn attribute(node: dom_query::NodeRef<'_>, name: &str) -> String {
    node.attr(name)
        .map(|value| value.to_string())
        .unwrap_or_default()
}

pub fn contains(ancestor: dom_query::NodeRef<'_>, node: dom_query::NodeRef<'_>) -> bool {
    std::ptr::eq(ancestor.tree, node.tree)
        && (ancestor.id == node.id
            || node
                .ancestors_it(None)
                .any(|parent| parent.id == ancestor.id))
}

pub fn utf16_len(value: &str) -> usize {
    value.encode_utf16().count()
}

pub fn parse_number(value: &str) -> f64 {
    let prefix: String = value
        .trim_start()
        .chars()
        .take_while(|c| c.is_ascii_digit() || matches!(c, '.' | '+' | '-'))
        .collect();
    prefix.parse().unwrap_or(0.0)
}

pub fn matches(node: dom_query::NodeRef<'_>, selector: &str) -> bool {
    crate::dom::matcher(selector).is_some_and(|matcher| node.is_match(&matcher))
}
