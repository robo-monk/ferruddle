//! Defuddle's Markdown dialect, rendered from the same inert DOM as extraction.
//!
//! Text, destinations and attribute labels each have separate escaping rules.
//! Kept HTML is serialized only after the unconditional safety pass.
use std::collections::HashSet;
use std::sync::LazyLock;

use dom_query::{Document, NodeRef};
use regex::Regex;
use url::Url;

use crate::{Error, MarkdownOutput};

static ENTITY: LazyLock<Regex> =
    LazyLock::new(|| Regex::new(r"(?i)&(?:#[0-9]+|#x[0-9a-f]+|[a-z][a-z0-9]*);").unwrap());
static ORDERED: LazyLock<Regex> = LazyLock::new(|| Regex::new(r"^[ \t]*([0-9]+)([.)]) ").unwrap());
static YOUTUBE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r"^(?:www\.)?(?:youtube\.com|youtube-nocookie\.com|youtu\.be)$").unwrap()
});

pub fn convert(html: &str, page_url: Option<&str>) -> Result<MarkdownOutput, Error> {
    let document = Document::from(html);
    let warnings = crate::math::warnings(&document);
    crate::safety::sanitize(document.root());
    let root = document.body().unwrap_or_else(|| document.root());
    let markdown = convert_node(root, page_url);
    Ok(MarkdownOutput { markdown, warnings })
}

/// Render a DOM which has already passed through `safety::sanitize`.
/// Kept private to the crate so callers cannot accidentally bypass sanitization.
pub(crate) fn convert_node(root: NodeRef<'_>, page_url: Option<&str>) -> String {
    let definitions = root
        .descendants_it()
        .filter_map(|node| {
            node.attr("id")
                .and_then(|id| id.strip_prefix("fn:").map(str::to_owned))
        })
        .collect();
    let base_url = page_url.and_then(|value| Url::parse(value).ok());
    let renderer = Renderer {
        definitions,
        base_url,
    };
    let mut markdown = renderer.render(root, Context::default());
    markdown = markdown.trim().to_owned();
    // Defuddle excludes a leading article title from Markdown.
    if markdown.starts_with("# ")
        && let Some(end) = markdown.find('\n')
    {
        markdown = markdown[end..].trim_start().to_owned();
    } else if markdown.starts_with("# ") {
        markdown.clear();
    }
    markdown
}

#[derive(Clone, Copy, Default)]
struct Context {
    in_table: bool,
    depth: usize,
}

struct Renderer {
    definitions: HashSet<String>,
    base_url: Option<Url>,
}

impl Renderer {
    fn children(&self, node: NodeRef<'_>, context: Context) -> String {
        let mut output = String::new();
        let mut inline = String::new();
        let mut children = node.children_it(false).peekable();
        while let Some(child) = children.next() {
            if let Some(kind) = inline_kind(child) {
                let mut siblings = vec![child];
                while let Some(next) = children.peek().copied() {
                    if inline_kind(next) == Some(kind) {
                        siblings.push(children.next().unwrap());
                    } else if !source_block(next) && self.render(next, context).is_empty() {
                        children.next();
                    } else {
                        break;
                    }
                }
                if siblings.len() > 1 {
                    let joined = if kind == "code" {
                        code_span(
                            &siblings
                                .iter()
                                .map(|node| node.text().to_string())
                                .collect::<String>(),
                        )
                    } else {
                        let mut inner = String::new();
                        for sibling in siblings {
                            append(&mut inner, &self.children(sibling, context));
                        }
                        delimit(&inner, kind)
                    };
                    append(&mut inline, &joined);
                    continue;
                }
            }
            if source_block(child) || node_tag(child) == "br" {
                flush_inline(&mut output, &mut inline);
                append(&mut output, &self.render(child, context));
            } else {
                append(&mut inline, &self.render(child, context));
            }
        }
        flush_inline(&mut output, &mut inline);
        output
    }

    fn render(&self, node: NodeRef<'_>, context: Context) -> String {
        if context.depth > 512 {
            return escape_text(&collapse_spaces(&node.text()));
        }
        let context = Context {
            depth: context.depth + 1,
            ..context
        };
        if node.is_text() {
            return escape_text(&collapse_spaces(&node.text()));
        }
        if node.is_comment() || node.is_doctype() {
            return String::new();
        }
        let tag = node_tag(node);
        if tag == "script"
            && node
                .attr("type")
                .is_some_and(|kind| kind.to_ascii_lowercase().starts_with("math/"))
        {
            let source = node.text();
            if node
                .attr("type")
                .is_some_and(|kind| kind.contains("mode=display"))
            {
                let fence = "`".repeat(3.max(longest_backticks(&source) + 1));
                return block(&format!("{fence}\n{source}\n{fence}"));
            }
            return code_span(&source);
        }
        if matches!(
            tag.as_str(),
            "script" | "style" | "head" | "template" | "noscript" | "wbr" | "input"
        ) {
            return String::new();
        }
        if node.has_class("footnote-backref")
            || node
                .attr("href")
                .is_some_and(|href| href.contains("#fnref"))
        {
            return String::new();
        }
        if tag == "sup"
            && let Some(reference) = node
                .attr("id")
                .and_then(|id| id.strip_prefix("fnref:").map(str::to_owned))
        {
            let linked = first(node, |n| {
                node_tag(n) == "a" && n.attr("href").is_some_and(|v| v.starts_with("#fn:"))
            })
            .and_then(|n| n.attr("href"))
            .map(|v| decode_fragment(&v[4..]));
            let primary = linked.unwrap_or_else(|| {
                if self.definitions.contains(&reference) {
                    reference.clone()
                } else {
                    reference
                        .rsplit_once('-')
                        .filter(|(_, suffix)| suffix.chars().all(|c| c.is_ascii_digit()))
                        .map(|(id, _)| id.to_owned())
                        .unwrap_or(reference)
                }
            });
            return format!("[^{}]", footnote_id(&primary));
        }
        if node.has_class("callout") && node.attr("data-callout").is_some() {
            return self.callout(node, context);
        }
        // Math is deliberately preserved as safe source, never translated to LaTeX.
        if tag == "math"
            || node.has_class("katex")
            || node.has_class("math")
            || node.attr("data-latex").is_some()
        {
            return node.html().to_string();
        }
        match tag.as_str() {
            "pre" => self.pre(node, context),
            "code" | "tt" => code_span(&node.text()),
            "table" => self.table(node, context),
            "ul" | "ol"
                if tag == "ol"
                    && node.parent().is_some_and(|n| {
                        n.attr("id").is_some_and(|id| id.as_ref() == "footnotes")
                    }) =>
            {
                self.footnotes(node, context)
            }
            "ul" | "ol" => self.list(node, context),
            "figure" => self.figure(node, context),
            "img" => self.image(node),
            "iframe" | "video" | "audio" => self.media(node),
            "sup" | "sub" | "svg" => node.html().to_string(),
            "br" => {
                if context.in_table {
                    "<br>".into()
                } else {
                    "  \n".into()
                }
            }
            "hr" => block("---"),
            "h1" | "h2" | "h3" | "h4" | "h5" | "h6" => {
                let body = self
                    .children(node, context)
                    .replace("  \n", " ")
                    .replace('\n', " ");
                block(&format!(
                    "{} {}",
                    "#".repeat(tag.as_bytes()[1] as usize - b'0' as usize),
                    body.trim()
                ))
            }
            "a" => self.link(node, context),
            "strong" | "b" => delimit(&self.children(node, context), "**"),
            "em" | "i" => delimit(&self.children(node, context), "*"),
            "del" | "s" | "strike" => delimit(&self.children(node, context), "~~"),
            "mark" => delimit(&self.children(node, context), "=="),
            "blockquote" => {
                let body = self.children(node, context);
                let mut lines = Vec::new();
                for line in body.trim().lines() {
                    let line = if line.is_empty() {
                        ">".to_owned()
                    } else {
                        format!("> {line}")
                    };
                    if line == ">" && lines.last().is_some_and(|previous| previous == ">") {
                        continue;
                    }
                    lines.push(line);
                }
                block(&lines.join("\n"))
            }
            "p" => block(&escape_block_prefix(self.children(node, context).trim())),
            "div" | "article" | "section" | "main" | "header" | "footer" | "aside"
            | "figcaption" | "address" | "details" | "summary" | "dl" | "dt" | "dd" | "center"
            | "fieldset" | "form" => block(self.children(node, context).trim()),
            _ => self.children(node, context),
        }
    }

    fn destination(&self, value: &str, image: bool) -> String {
        if dangerous_url(value, image) {
            return String::new();
        }
        // Standalone conversion leaves relative destinations as authored; extraction
        // resolves these beforehand. A base URL is still useful for media URLs.
        destination(value)
    }

    fn link(&self, node: NodeRef<'_>, context: Context) -> String {
        let content = self.children(node, context);
        let href = node.attr("href").unwrap_or_default();
        let destination = self.destination(&href, false);
        if destination.is_empty() || content.trim().is_empty() {
            return content;
        }
        let title = title(node.attr("title").as_deref());
        if node.children_it(false).count() > 1
            && node.children_it(false).any(|n| {
                matches!(
                    node_tag(n).as_str(),
                    "h1" | "h2" | "h3" | "h4" | "h5" | "h6"
                )
            })
        {
            return block(&format!(
                "{}\n\n[View original]({destination}{title})",
                content.trim()
            ));
        }
        let leading = &content[..content.len() - content.trim_start().len()];
        let trailing = &content[content.trim_end().len()..];
        format!(
            "{leading}[{}]({destination}{title}){trailing}",
            content.trim()
        )
    }

    fn image(&self, node: NodeRef<'_>) -> String {
        let source = best_image_src(node);
        let destination = self.destination(&source, true);
        if destination.is_empty() {
            return String::new();
        }
        let alt = escape_text(&collapse_spaces(&node.attr("alt").unwrap_or_default()));
        format!(
            "![{alt}]({destination}{})",
            title(node.attr("title").as_deref())
        )
    }

    fn figure(&self, node: NodeRef<'_>, context: Context) -> String {
        // Figure wrappers can also contain image links, credits and surrounding
        // prose. Render every child rather than selecting only one image/caption.
        block(self.children(node, context).trim())
    }

    fn media(&self, node: NodeRef<'_>) -> String {
        if let Some(source) = node.attr("src") {
            let parsed = Url::parse(&source).ok().or_else(|| {
                self.base_url
                    .as_ref()
                    .and_then(|base| base.join(&source).ok())
            });
            if let Some(url) = parsed {
                let host = url.host_str().unwrap_or_default();
                if YOUTUBE.is_match(host) {
                    let path: Vec<_> = url.path_segments().into_iter().flatten().collect();
                    let id = if host.ends_with("youtu.be") {
                        path.first().map(|s| (*s).to_owned())
                    } else if path.first() == Some(&"embed") {
                        path.get(1).map(|s| (*s).to_owned())
                    } else {
                        url.query_pairs()
                            .find(|(key, _)| key == "v")
                            .map(|(_, id)| id.into_owned())
                    };
                    if let Some(id) = id.filter(|id| {
                        !id.is_empty()
                            && id
                                .chars()
                                .all(|c| c.is_ascii_alphanumeric() || c == '_' || c == '-')
                    }) {
                        return block(&format!("![](https://www.youtube.com/watch?v={id})"));
                    }
                }
                if matches!(
                    host,
                    "x.com" | "www.x.com" | "twitter.com" | "www.twitter.com"
                ) {
                    let path: Vec<_> = url.path_segments().into_iter().flatten().collect();
                    if path.len() >= 3
                        && path[1] == "status"
                        && path[0]
                            .chars()
                            .all(|c| c.is_ascii_alphanumeric() || c == '_')
                        && path[2].chars().all(|c| c.is_ascii_digit())
                        && !path[2].is_empty()
                    {
                        return block(&format!(
                            "![](https://x.com/{}/status/{})",
                            path[0], path[2]
                        ));
                    }
                }
                if host == "platform.twitter.com"
                    && url.path() == "/embed/Tweet.html"
                    && let Some(id) = url
                        .query_pairs()
                        .find(|(key, id)| {
                            key == "id" && !id.is_empty() && id.chars().all(|c| c.is_ascii_digit())
                        })
                        .map(|(_, id)| id.into_owned())
                {
                    return block(&format!("![](https://x.com/i/status/{id})"));
                }
            }
        }
        block(&node.html())
    }

    fn pre(&self, node: NodeRef<'_>, context: Context) -> String {
        let code = first(node, |n| node_tag(n) == "code").unwrap_or(node);
        let mut text = String::new();
        pre_text(node, &mut text, 0);
        if context.in_table {
            return code_span(&text);
        }
        let language = code
            .attr("data-lang")
            .or_else(|| code.attr("data-language"))
            .or_else(|| {
                code.attr("class").and_then(|classes| {
                    classes
                        .split_whitespace()
                        .find_map(|class| class.strip_prefix("language-").map(Into::into))
                })
            })
            .or_else(|| node.attr("data-language"))
            .unwrap_or_default();
        let language = language
            .split_whitespace()
            .next()
            .unwrap_or("")
            .replace('`', "");
        // Preserve indentation and internal blank lines. Remove only the customary
        // boundary newline, never significant source spaces.
        let text = text.strip_prefix('\n').unwrap_or(&text);
        let text = text.strip_suffix('\n').unwrap_or(text);
        let fence = "`".repeat(3.max(longest_backticks(text) + 1));
        block(&format!("{fence}{language}\n{text}\n{fence}"))
    }

    fn list(&self, node: NodeRef<'_>, context: Context) -> String {
        let ordered = node_tag(node) == "ol";
        let start = node
            .attr("start")
            .and_then(|value| value.parse::<i64>().ok())
            .unwrap_or(1);
        let count = node
            .children_it(false)
            .filter(|child| node_tag(*child) == "li")
            .count();
        if ordered
            && (node.has_attr("reversed")
                || node
                    .children_it(false)
                    .any(|child| node_tag(child) == "li" && child.has_attr("value"))
                || node.attr("type").is_some_and(|kind| kind.as_ref() != "1")
                || start < 0
                || start.saturating_add(count.saturating_sub(1) as i64) > 999_999_999)
        {
            // CommonMark has no negative or ten-digit ordered list markers.
            return block(&node.html());
        }
        let mut items = Vec::new();
        for (index, item) in node
            .children_it(false)
            .filter(|n| node_tag(*n) == "li")
            .enumerate()
        {
            let mut body = self.children(item, context).trim().to_owned();
            let mut marker = if ordered {
                format!("{}. ", start.saturating_add(index as i64))
            } else {
                "- ".to_owned()
            };
            let continuation = if marker.len() <= 4 {
                "\t".to_owned()
            } else {
                " ".repeat(marker.len())
            };
            if let Some(checkbox) = first(item, |n| {
                node_tag(n) == "input"
                    && n.attr("type")
                        .is_some_and(|value| value.eq_ignore_ascii_case("checkbox"))
                    && n.ancestors_it(None)
                        .find(|ancestor| node_tag(*ancestor) == "li")
                        .is_some_and(|owner| owner.id == item.id)
            }) {
                marker.push_str(if checkbox.has_attr("checked") {
                    "[x] "
                } else {
                    "[ ] "
                });
            }
            // arXiv numbering is already supplied by the list marker.
            if node.has_class("ltx_enumerate")
                && let Some(label) = first(item, |n| n.has_class("ltx_tag_item"))
            {
                let prefix = escape_text(&collapse_spaces(&label.text()));
                body = body
                    .trim_start()
                    .strip_prefix(&prefix)
                    .unwrap_or(&body)
                    .trim_start()
                    .to_owned();
            }
            let mut lines = body.lines();
            let first = lines.next().unwrap_or("");
            let mut rendered = format!("{marker}{first}");
            for line in lines {
                rendered.push('\n');
                rendered.push_str(&continuation);
                rendered.push_str(line);
            }
            items.push(rendered);
        }
        block(&items.join("\n"))
    }

    fn footnotes(&self, node: NodeRef<'_>, context: Context) -> String {
        let mut definitions = Vec::new();
        for item in node.children_it(false).filter(|n| node_tag(*n) == "li") {
            let id = item.attr("id").unwrap_or_default();
            let id = id.strip_prefix("fn:").unwrap_or(&id);
            let content = self.children(item, context);
            let content = content.trim().trim_end_matches('↩').trim();
            let mut lines = content.lines();
            let mut definition = format!("[^{}]: {}", footnote_id(id), lines.next().unwrap_or(""));
            // Continuation indentation is required for paragraph/list/code blocks
            // to remain inside the footnote in CommonMark extensions.
            for line in lines {
                definition.push_str("\n    ");
                definition.push_str(line);
            }
            definitions.push(definition);
        }
        block(&definitions.join("\n\n"))
    }

    fn callout(&self, node: NodeRef<'_>, context: Context) -> String {
        let raw_type = node.attr("data-callout").unwrap_or_else(|| "note".into());
        let kind = if !raw_type.is_empty()
            && raw_type
                .chars()
                .all(|c| c.is_ascii_alphanumeric() || c == '_' || c == '-')
        {
            raw_type.as_ref()
        } else {
            "note"
        };
        let fold = node.attr("data-callout-fold").unwrap_or_default();
        let fold = if fold.as_ref() == "+" || fold.as_ref() == "-" {
            fold.as_ref()
        } else {
            ""
        };
        let default_title = format!("{}{}", kind[..1].to_ascii_uppercase(), &kind[1..]);
        let heading = first(node, |n| n.has_class("callout-title-inner"))
            .map(|n| collapse_spaces(&n.text()))
            .unwrap_or(default_title);
        let mut content = String::new();
        if let Some(body) = first(node, |n| n.has_class("callout-content")) {
            content = self.children(body, context);
        } else {
            for child in node
                .children_it(false)
                .filter(|n| !n.has_class("callout-title"))
            {
                append(&mut content, &self.render(child, context));
            }
        }
        let mut result = format!("> [!{kind}]{fold} {}", escape_text(heading.trim()));
        for line in content.trim().lines() {
            result.push_str("\n> ");
            result.push_str(line);
        }
        block(&result)
    }

    fn table(&self, node: NodeRef<'_>, context: Context) -> String {
        let rows: Vec<_> = node
            .descendants_it()
            .filter(|n| {
                node_tag(*n) == "tr" && nearest_table(*n).is_some_and(|table| table.id == node.id)
            })
            .collect();
        let cells: Vec<Vec<_>> = rows
            .iter()
            .map(|row| {
                row.children_it(false)
                    .filter(|n| matches!(node_tag(*n).as_str(), "td" | "th"))
                    .collect()
            })
            .collect();
        let caption = node
            .children_it(false)
            .find(|n| node_tag(*n) == "caption")
            .map(|n| self.children(n, context))
            .unwrap_or_default();
        let nested = node.descendants_it().any(|n| node_tag(n) == "table");
        let single_column = !cells.is_empty() && cells.iter().all(|row| row.len() <= 1);
        if nested || single_column {
            let mut result = block(caption.trim());
            for row in &cells {
                for cell in row {
                    append(&mut result, &block(self.children(*cell, context).trim()));
                }
            }
            return block(result.trim());
        }
        let width = cells.iter().map(Vec::len).max().unwrap_or(0);
        let alignment: Vec<_> = (0..width)
            .map(|column| {
                cells
                    .iter()
                    .find_map(|row| row.get(column).and_then(|cell| cell_alignment(*cell)))
            })
            .collect();
        let mixed_alignment = cells.iter().any(|row| {
            row.iter().enumerate().any(|(column, cell)| {
                alignment[column].is_some() && cell_alignment(*cell) != alignment[column]
            })
        });
        let rich_cells = cells.iter().flatten().any(|cell| {
            cell.descendants_it().any(|child| {
                matches!(
                    node_tag(child).as_str(),
                    "pre"
                        | "ul"
                        | "ol"
                        | "blockquote"
                        | "hr"
                        | "h1"
                        | "h2"
                        | "h3"
                        | "h4"
                        | "h5"
                        | "h6"
                )
            }) || cell
                .children_it(false)
                .filter(|child| node_tag(*child) == "p")
                .count()
                > 1
        });
        if mixed_alignment
            || rich_cells
            || cells
                .iter()
                .flatten()
                .any(|n| n.has_attr("colspan") || n.has_attr("rowspan"))
        {
            // Source attributes have already passed through unconditional
            // sanitization. Preserve meaningful nested-list, task and code attrs;
            // stripping an inert script's MIME type could make it executable.
            let copy = Document::fragment_sink();
            let table = crate::dom::clone_into(node, &copy.tree);
            let scripts: Vec<_> = table
                .descendants_it()
                .filter(|node| node_tag(*node) == "script")
                .collect();
            for script in scripts {
                script.update(|node| {
                    if let dom_query::NodeData::Element(element) = &mut node.data {
                        element.name.local = "code".into();
                    }
                });
                script.remove_all_attrs();
            }
            return block(&table.html());
        }
        if width == 0 {
            return self.children(node, context);
        }
        let mut result = Vec::new();
        for (index, row) in cells.iter().enumerate() {
            let mut values: Vec<_> = row
                .iter()
                .map(|cell| {
                    self.children(
                        *cell,
                        Context {
                            in_table: true,
                            ..context
                        },
                    )
                    .trim()
                    .replace('\n', " ")
                    .replace('|', "\\|")
                })
                .collect();
            values.resize(width, String::new());
            result.push(format!("| {} |", values.join(" | ")));
            if index == 0 {
                let separators: Vec<_> = alignment
                    .iter()
                    .map(|align| match align.as_deref() {
                        Some("left") => ":---",
                        Some("center") => ":---:",
                        Some("right") => "---:",
                        _ => "---",
                    })
                    .collect();
                result.push(format!("| {} |", separators.join(" | ")));
            }
        }
        if caption.trim().is_empty() {
            block(&result.join("\n"))
        } else {
            block(&format!("{}\n\n{}", caption.trim(), result.join("\n")))
        }
    }
}

fn node_tag(node: NodeRef<'_>) -> String {
    node.node_name()
        .map(|n| n.to_ascii_lowercase())
        .unwrap_or_default()
}
fn first<'a>(node: NodeRef<'a>, predicate: impl Fn(NodeRef<'a>) -> bool) -> Option<NodeRef<'a>> {
    node.descendants_it().find(|n| predicate(*n))
}
fn nearest_table(node: NodeRef<'_>) -> Option<NodeRef<'_>> {
    node.ancestors_it(None).find(|n| node_tag(*n) == "table")
}
fn block(content: &str) -> String {
    if content.is_empty() {
        String::new()
    } else {
        format!("\n\n{content}\n\n")
    }
}

/// Join at block boundaries without normalizing the interior of code or kept HTML.
fn append(output: &mut String, content: &str) {
    if content.is_empty() {
        return;
    }
    if content.starts_with('\n') {
        output.truncate(output.trim_end_matches([' ', '\t']).len());
    }
    let trailing = output.len() - output.trim_end_matches('\n').len();
    let leading = content.len() - content.trim_start_matches('\n').len();
    let mut content = content;
    if trailing + leading > 2 {
        content = &content[(trailing + leading - 2).min(leading)..];
    }
    if output.ends_with('\n') && content.starts_with(' ') {
        content = content.trim_start_matches(' ');
    }
    if output.ends_with(' ') && content.starts_with(' ') {
        content = &content[1..];
    }
    // A literal exclamation immediately before an image changes Markdown parsing.
    if output.ends_with('!') && (content.starts_with("![") || content.starts_with("[![")) {
        output.push(' ');
    }
    output.push_str(content);
}

fn collapse_spaces(value: &str) -> String {
    let mut output = String::with_capacity(value.len());
    let mut previous_space = false;
    for ch in value.chars() {
        if matches!(ch, ' ' | '\t' | '\r' | '\n' | '\x0c' | '\u{a0}') {
            if !previous_space {
                output.push(' ');
            }
            previous_space = true;
        } else {
            output.push(ch);
            previous_space = false;
        }
    }
    output
}

fn escape_entities(value: &str) -> String {
    ENTITY
        .replace_all(value, |caps: &regex::Captures<'_>| {
            format!("&amp;{}", &caps[0][1..])
        })
        .into_owned()
}

fn escape_text(value: &str) -> String {
    let value = escape_entities(value);
    let mut output = String::with_capacity(value.len());
    let first_content = value.len() - value.trim_start_matches(char::is_whitespace).len();
    let chars = value.char_indices().peekable();
    for (index, ch) in chars {
        match ch {
            '\\' | '*' | '_' | '`' | '[' | ']' => {
                output.push('\\');
                output.push(ch);
            }
            '<' => {
                // Complete HTTPS/email autolinks are safe. Always escape an open
                // bracket at a text-node boundary to prevent split HTML injection.
                let rest = &value[index + 1..];
                let safe = rest.find('>').is_some_and(|end| {
                    let target = &rest[..end];
                    !target.chars().any(char::is_whitespace)
                        && (target.starts_with("https://")
                            || target.starts_with("http://")
                            || (target.contains('@') && !target.contains(':')))
                });
                if !safe {
                    output.push('\\');
                }
                output.push('<');
            }
            '#' | '+' | '-' | '=' | '~' | '>' if index == first_content => {
                output.push('\\');
                output.push(ch);
            }
            _ => output.push(ch),
        }
    }
    if let Some(caps) = ORDERED.captures(&output) {
        let index = caps.get(1).unwrap().end();
        output.insert(index, '\\');
    }
    output
}

fn delimit(content: &str, delimiter: &str) -> String {
    if content.trim().is_empty() {
        return content.to_owned();
    }
    let leading = &content[..content.len() - content.trim_start().len()];
    let trailing = &content[content.trim_end().len()..];
    format!(
        "{leading}{delimiter}{}{delimiter}{trailing}",
        content.trim()
    )
}

fn longest_backticks(value: &str) -> usize {
    let mut longest = 0;
    let mut current = 0;
    for byte in value.bytes() {
        if byte == b'`' {
            current += 1;
            longest = longest.max(current);
        } else {
            current = 0;
        }
    }
    longest
}

fn code_span(value: &str) -> String {
    if value.is_empty() {
        return String::new();
    }
    let value = value.replace(['\n', '\r'], " ");
    let fence = "`".repeat(longest_backticks(&value) + 1);
    let pad = value.starts_with('`')
        || value.ends_with('`')
        || (value.starts_with(' ') && value.ends_with(' ') && !value.trim().is_empty());
    if pad {
        format!("{fence} {value} {fence}")
    } else {
        format!("{fence}{value}{fence}")
    }
}

fn dangerous_url(value: &str, image: bool) -> bool {
    crate::safety::is_dangerous_url(value, image)
}

fn destination(value: &str) -> String {
    let value = escape_entities(value);
    let spaces = value.chars().any(char::is_whitespace);
    let mut output = String::with_capacity(value.len());
    for ch in value.chars() {
        match ch {
            '\\' => output.push_str("\\\\"),
            '<' | '>' | '\x00'..='\x1f' | '\x7f' => {
                for byte in ch.to_string().bytes() {
                    output.push_str(&format!("%{byte:02X}"));
                }
            }
            '(' | ')' if !spaces => {
                output.push('\\');
                output.push(ch);
            }
            _ => output.push(ch),
        }
    }
    if spaces {
        format!("<{output}>")
    } else {
        output
    }
}

fn title(value: Option<&str>) -> String {
    let Some(value) = value.filter(|v| !v.is_empty()) else {
        return String::new();
    };
    let value = value
        .replace(['\r', '\n'], " ")
        .replace('\\', "\\\\")
        .replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
        .replace('"', "&quot;");
    format!(" \"{value}\"")
}

fn best_image_src(node: NodeRef<'_>) -> String {
    let mut best = None;
    if let Some(srcset) = node.attr("srcset") {
        for (url, descriptor) in crate::dom::srcset_candidates(&srcset) {
            if let Some(width) = descriptor
                .strip_suffix('w')
                .and_then(|v| v.parse::<u32>().ok())
                && !url.is_empty()
                && !dangerous_url(&url, true)
                && best
                    .as_ref()
                    .is_none_or(|(best_width, _)| width > *best_width)
            {
                best = Some((width, url));
            }
        }
    }
    best.map(|(_, value)| value)
        .unwrap_or_else(|| node.attr("src").unwrap_or_default().to_string())
}

fn footnote_id(value: &str) -> String {
    let mut output = String::new();
    for ch in value.to_lowercase().encode_utf16() {
        if (ch as u32 <= 127)
            && (char::from_u32(ch as u32).unwrap().is_ascii_alphanumeric()
                || ch == b'_' as u16
                || ch == b'-' as u16)
        {
            output.push(char::from_u32(ch as u32).unwrap());
        } else {
            output.push_str(&format!("%{ch:04x}"));
        }
    }
    output
}

fn decode_fragment(value: &str) -> String {
    let mut decoded = Vec::with_capacity(value.len());
    let bytes = value.as_bytes();
    let mut index = 0;
    while index < bytes.len() {
        if bytes[index] == b'%' {
            if index + 2 >= bytes.len() {
                return value.to_owned();
            }
            let (Some(hi), Some(lo)) = (
                (bytes[index + 1] as char).to_digit(16),
                (bytes[index + 2] as char).to_digit(16),
            ) else {
                return value.to_owned();
            };
            let byte = (hi * 16 + lo) as u8;
            decoded.push(byte);
            index += 3;
        } else {
            decoded.push(bytes[index]);
            index += 1;
        }
    }
    String::from_utf8(decoded).unwrap_or_else(|_| value.to_owned())
}

/// Escape a literal paragraph prefix after inline wrappers and edge whitespace
/// have been rendered. This also catches ordered markers split across spans.
fn escape_block_prefix(value: &str) -> String {
    if value.starts_with(['#', '+', '-', '>']) || value.starts_with("~~~") {
        return format!("\\{value}");
    }
    if let Some(captures) = ORDERED.captures(value) {
        let index = captures.get(1).unwrap().end();
        let mut value = value.to_owned();
        value.insert(index, '\\');
        return value;
    }
    value.to_owned()
}

fn pre_text(node: NodeRef<'_>, output: &mut String, depth: usize) {
    if node.is_text() {
        output.push_str(&node.text());
        return;
    }
    if depth > 512 {
        output.push_str(&node.text());
        return;
    }
    let tag = node_tag(node);
    if matches!(
        tag.as_str(),
        "button" | "script" | "style" | "template" | "noscript"
    ) {
        return;
    }
    if tag == "br" {
        output.push('\n');
        return;
    }
    let block = matches!(tag.as_str(), "div" | "p" | "li" | "tr");
    if block && !output.is_empty() && !output.ends_with('\n') {
        output.push('\n');
    }
    for child in node.children_it(false) {
        pre_text(child, output, depth + 1);
    }
    if block && !output.ends_with('\n') {
        output.push('\n');
    }
}

fn cell_alignment(node: NodeRef<'_>) -> Option<String> {
    let mut alignment = node
        .attr("align")
        .map(|value| value.trim().to_ascii_lowercase());
    if let Some(style) = node.attr("style") {
        for (name, value) in style.split(';').filter_map(|entry| entry.split_once(':')) {
            if name.trim().eq_ignore_ascii_case("text-align") {
                alignment = Some(
                    value
                        .trim()
                        .to_ascii_lowercase()
                        .trim_end_matches("!important")
                        .trim()
                        .to_owned(),
                );
            }
        }
    }
    alignment.filter(|value| matches!(value.as_str(), "left" | "center" | "right"))
}

// Track authored block boundaries before rendering so literal marker fragments
// split across inline nodes cannot become generated Markdown structure.
fn source_block(node: NodeRef<'_>) -> bool {
    fn native(node: NodeRef<'_>) -> bool {
        matches!(
            node_tag(node).as_str(),
            "p" | "div"
                | "h1"
                | "h2"
                | "h3"
                | "h4"
                | "h5"
                | "h6"
                | "article"
                | "section"
                | "main"
                | "header"
                | "footer"
                | "aside"
                | "figcaption"
                | "figure"
                | "address"
                | "details"
                | "summary"
                | "dl"
                | "dt"
                | "dd"
                | "center"
                | "fieldset"
                | "form"
                | "pre"
                | "blockquote"
                | "ul"
                | "ol"
                | "li"
                | "table"
                | "thead"
                | "tbody"
                | "tfoot"
                | "tr"
                | "td"
                | "th"
                | "hr"
        )
    }
    node.is_element() && (native(node) || node.descendants_it().any(native))
}

fn flush_inline(output: &mut String, inline: &mut String) {
    let start = inline.len() - inline.trim_start_matches([' ', '\t']).len();
    let escaped = escape_block_prefix(&inline[start..]);
    let mut content = String::with_capacity(inline.len() + 1);
    content.push_str(&inline[..start]);
    content.push_str(&escaped);
    append(output, &content);
    inline.clear();
}

fn inline_kind(node: NodeRef<'_>) -> Option<&'static str> {
    if node.has_class("math")
        || node.has_class("katex")
        || node.has_class("footnote-backref")
        || node.has_attr("data-latex")
        || node
            .attr("href")
            .is_some_and(|href| href.contains("#fnref"))
    {
        return None;
    }
    match node_tag(node).as_str() {
        "code" | "tt" => Some("code"),
        "strong" | "b" => Some("**"),
        "em" | "i" => Some("*"),
        "del" | "s" | "strike" => Some("~~"),
        "mark" => Some("=="),
        _ => None,
    }
}
