//! Extraction attempts operate on independent clones of the same inert DOM.
use crate::{
    DebugInfo, Error, Extraction, Metadata, Options, Warning, dom, extractors, finalize, math,
    metadata, patterns, removals, safety, selection, standardize,
    utils::{count_words, tag},
};
use dom_query::{Document, NodeId, NodeRef};
use serde_json::Value;

pub fn extract(html: &str, page_url: Option<&str>, options: &Options) -> Result<Extraction, Error> {
    let original = Document::from(html);
    let warnings = math::warnings(&original);
    let metadata = metadata::extract(&original, page_url);
    dom::preprocess(&original);
    // Root safety is determined before any cleanup can retag the element. An
    // explicit unsafe selection cannot be replaced by retry or schema content.
    if let Some(root) = options
        .content_selector
        .as_deref()
        .and_then(|s| dom::select(original.root(), s).first().copied())
        .filter(|n| safety::is_unsafe_element(*n))
    {
        let debug = DebugInfo {
            content_selector: node_path(root),
            ..Default::default()
        };
        safety::sanitize(root);
        return Ok(finish(
            root, true, false, page_url, options, metadata, warnings, None, debug,
        ));
    }
    if options.remove_images {
        for n in dom::select(original.root(), "img,picture,source") {
            n.remove_from_parent();
        }
    }
    if let Some(adapter) = extractors::extract(&original, page_url, options, &metadata) {
        if let Some(html) = adapter.content_html {
            return Ok(from_html(
                &html,
                page_url,
                options,
                adapter.metadata,
                warnings,
                Some(adapter.extractor_type),
                &original,
            ));
        }
        if let Some(selector) = adapter.content_selector {
            let mut selected = options.clone();
            selected.content_selector = Some(selector);
            selected.remove_low_scoring = false;
            selected.remove_hidden_elements = false;
            let mut result = attempt(
                &original,
                page_url,
                &selected,
                &adapter.metadata,
                &warnings,
                None,
            );
            result.extractor_type = Some(adapter.extractor_type);
            return Ok(result);
        }
    }
    let mut result = attempt(&original, page_url, options, &metadata, &warnings, None);
    // Disabling a selective pass must make a substantial difference before it
    // can replace a successful short article with surrounding page furniture.
    if result.word_count < 200 && options.remove_partial_selectors {
        let mut retry = options.clone();
        retry.remove_partial_selectors = false;
        let candidate = attempt(&original, page_url, &retry, &metadata, &warnings, None);
        if candidate.word_count > result.word_count * 2 {
            result = candidate
        }
    }
    if result.word_count < 50 && options.remove_hidden_elements {
        let mut retry = options.clone();
        retry.remove_hidden_elements = false;
        let candidate = attempt(&original, page_url, &retry, &metadata, &warnings, None);
        if candidate.word_count > result.word_count * 2 {
            result = candidate
        }
        let hidden = dom::select(
            original.root(),
            crate::constants::HIDDEN_EXACT_SKIP_SELECTOR,
        )
        .into_iter()
        .filter(|n| {
            !crate::utils::attribute(*n, "class").contains("math") && count_words(&n.text()) >= 30
        })
        .max_by_key(|n| count_words(&n.text()));
        if let Some(hidden) = hidden {
            retry.remove_partial_selectors = false;
            let candidate = attempt(
                &original,
                page_url,
                &retry,
                &metadata,
                &warnings,
                Some(hidden.id),
            );
            if candidate.word_count > result.word_count
                || (candidate.word_count > 20.max(result.word_count * 7 / 10)
                    && candidate.content.len() < result.content.len())
            {
                result = candidate
            }
        }
    }
    if result.word_count < 50 {
        let mut retry = options.clone();
        retry.remove_low_scoring = false;
        retry.remove_partial_selectors = false;
        retry.remove_content_patterns = false;
        let candidate = attempt(&original, page_url, &retry, &metadata, &warnings, None);
        if candidate.word_count > result.word_count {
            result = candidate
        }
    }
    let schema = schema_text(&metadata.schema_org_data, 0);
    if !schema.is_empty()
        && count_words(&Document::fragment(schema).text()) as f64 > result.word_count as f64 * 1.5
    {
        if let Some(node) = schema_element(&original, schema) {
            result = attempt(
                &original,
                page_url,
                options,
                &metadata,
                &warnings,
                Some(node.id),
            );
        } else {
            result = from_html(
                schema,
                page_url,
                options,
                metadata.clone(),
                warnings.clone(),
                None,
                &original,
            );
        }
    }
    Ok(result)
}

fn attempt(
    doc: &Document,
    page_url: Option<&str>,
    options: &Options,
    metadata: &Metadata,
    warnings: &[Warning],
    forced: Option<NodeId>,
) -> Extraction {
    let clone = doc.clone();
    // Selector adapters can materialize images and math from embedded JSON
    // after preprocessing; enforce options and warnings on that content too.
    let warnings = if warnings.is_empty() {
        math::warnings(&clone)
    } else {
        warnings.to_vec()
    };
    if options.remove_images {
        for node in dom::select(clone.root(), "img,picture,source") {
            node.remove_from_parent()
        }
    }
    let body = clone.tree.body().unwrap_or(clone.root());
    let mut root = forced
        .map(|id| NodeRef::new(id, &clone.tree))
        .or_else(|| selection::find_main(&clone, options.content_selector.as_deref()))
        .unwrap_or(body);
    if tag(root) == "body"
        && let Some(node) = schema_element(&clone, schema_text(&metadata.schema_org_data, 0))
    {
        root = node
    }
    let mut debug = DebugInfo::default();
    if options.debug {
        debug.content_selector = node_path(root);
        if let Some(selector) = &options.content_selector
            && dom_query::Matcher::new(selector).is_err()
        {
            debug
                .errors
                .push(format!("Invalid contentSelector: {selector}"));
        }
    }
    if safety::is_unsafe_element(root) {
        safety::sanitize(root);
        return finish(
            root,
            true,
            false,
            page_url,
            options,
            metadata.clone(),
            warnings.to_vec(),
            None,
            debug,
        );
    }
    let mut metadata = metadata.clone();
    if !metadata.author.is_empty() || !metadata.published.is_empty() {
        removals::remove_metadata_block(root)
    }
    for node in dom::select(root, "wbr") {
        node.remove_from_parent()
    }
    if options.standardize {
        standardize::before_removals(&clone, root, &metadata)
    }
    if options.remove_small_images {
        removals::remove_small_images(body, options.debug, &mut debug.removals)
    }
    if options.remove_hidden_elements {
        removals::remove_hidden(body, options.debug, &mut debug.removals)
    }
    if options.remove_content_patterns {
        patterns::eyebrow(root, options.debug, &mut debug.removals)
    }
    if options.remove_exact_selectors || options.remove_partial_selectors {
        removals::remove_selectors(body, root, options, &mut debug.removals)
    }
    if options.remove_low_scoring {
        removals::remove_low_scoring(body, root, options.debug, &mut debug.removals)
    }
    if options.remove_content_patterns {
        patterns::remove_patterns(
            root,
            page_url,
            &metadata,
            options.debug,
            &mut debug.removals,
        )
    }
    if options.standardize {
        standardize::content(root, &metadata, options)
    }
    finalize::urls(root, doc, page_url);
    finalize::images(root, &mut metadata);
    let unsafe_root = safety::sanitize(root);
    finish(
        root,
        unsafe_root,
        false,
        page_url,
        options,
        metadata,
        warnings.to_vec(),
        None,
        debug,
    )
}

fn from_html(
    html: &str,
    page_url: Option<&str>,
    options: &Options,
    metadata: Metadata,
    mut warnings: Vec<Warning>,
    kind: Option<String>,
    original: &Document,
) -> Extraction {
    let doc = Document::fragment(html);
    let root = doc.html_root();
    if warnings.is_empty() {
        warnings = math::warnings(&doc)
    }
    safety::sanitize(root);
    if options.remove_images {
        for node in dom::select(root, "img,picture,source") {
            node.remove_from_parent()
        }
    }
    if options.standardize {
        standardize::extractor(root, options)
    }
    finalize::urls(root, original, page_url);
    let unsafe_root = safety::sanitize(root);
    finish(
        root,
        unsafe_root,
        true,
        page_url,
        options,
        metadata,
        warnings,
        kind,
        DebugInfo::default(),
    )
}

#[allow(clippy::too_many_arguments)]
fn finish(
    root: NodeRef<'_>,
    unsafe_root: bool,
    inner: bool,
    page_url: Option<&str>,
    options: &Options,
    metadata: Metadata,
    warnings: Vec<Warning>,
    extractor_type: Option<String>,
    debug: DebugInfo,
) -> Extraction {
    let content = if unsafe_root {
        String::new()
    } else if inner {
        root.inner_html().trim().to_string()
    } else {
        root.html().trim().to_string()
    };
    let word_count = if unsafe_root {
        0
    } else {
        crate::utils::count_content_words(root)
    };
    let content_markdown = options.markdown.then(|| {
        if unsafe_root {
            String::new()
        } else {
            crate::markdown::convert_node(root, page_url)
        }
    });
    Extraction {
        content,
        content_markdown,
        metadata,
        word_count,
        extractor_type,
        warnings,
        debug: options.debug.then_some(debug),
    }
}

fn schema_text(value: &Value, depth: usize) -> &str {
    if depth > 10 {
        return "";
    }
    if let Some(items) = value.as_array() {
        return items
            .iter()
            .map(|v| schema_text(v, depth + 1))
            .find(|s| !s.is_empty())
            .unwrap_or("");
    }
    value
        .get("text")
        .and_then(Value::as_str)
        .filter(|s| !s.is_empty())
        .or_else(|| {
            value
                .get("articleBody")
                .and_then(Value::as_str)
                .filter(|s| !s.is_empty())
        })
        .unwrap_or_else(|| {
            value
                .get("@graph")
                .map(|v| schema_text(v, depth + 1))
                .unwrap_or("")
        })
}
fn schema_element<'a>(doc: &'a Document, text: &str) -> Option<NodeRef<'a>> {
    let first = text.split("\n\n").next().unwrap_or("").trim();
    if first.is_empty() {
        return None;
    }
    let phrase: String = first.chars().take(100).collect();
    let count = count_words(text);
    dom::select(doc.root(), "body *")
        .into_iter()
        .filter(|n| {
            let t = n.text();
            t.contains(&phrase) && count_words(&t) as f64 >= count as f64 * 0.8
        })
        .min_by_key(|n| count_words(&n.text()))
}
fn node_path(node: NodeRef<'_>) -> String {
    let mut path = Vec::new();
    for n in std::iter::once(node)
        .chain(node.ancestors_it(None))
        .filter(|n| n.is_element())
    {
        let index = n
            .parent()
            .map(|p| {
                p.element_children()
                    .iter()
                    .position(|s| s.id == n.id)
                    .unwrap_or(0)
                    + 1
            })
            .unwrap_or(1);
        path.push(format!("{}:nth-child({index})", tag(n)));
    }
    path.reverse();
    path.join(" > ")
}
