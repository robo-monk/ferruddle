use serde::{Deserialize, Serialize};
use serde_json::Value;

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct Options {
    pub markdown: bool,
    pub content_selector: Option<String>,
    pub remove_exact_selectors: bool,
    pub remove_partial_selectors: bool,
    pub remove_hidden_elements: bool,
    pub remove_low_scoring: bool,
    pub remove_small_images: bool,
    pub remove_content_patterns: bool,
    pub remove_images: bool,
    pub standardize: bool,
    pub include_replies: IncludeReplies,
    pub debug: bool,
}

impl Default for Options {
    fn default() -> Self {
        Self {
            markdown: false,
            content_selector: None,
            remove_exact_selectors: true,
            remove_partial_selectors: true,
            remove_hidden_elements: true,
            remove_low_scoring: true,
            remove_small_images: true,
            remove_content_patterns: true,
            remove_images: false,
            standardize: true,
            include_replies: IncludeReplies::Extractors,
            debug: false,
        }
    }
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum IncludeReplies {
    #[default]
    Extractors,
    All,
    None,
}

#[derive(Clone, Debug, Default, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct Metadata {
    pub title: String,
    pub description: String,
    pub domain: String,
    pub favicon: String,
    pub image: String,
    pub language: String,
    pub published: String,
    pub author: String,
    pub site: String,
    pub schema_org_data: Value,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Extraction {
    pub content: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub content_markdown: Option<String>,
    #[serde(flatten)]
    pub metadata: Metadata,
    pub word_count: usize,
    pub extractor_type: Option<String>,
    pub warnings: Vec<Warning>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub debug: Option<DebugInfo>,
}

#[derive(Clone, Debug, Default, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct DebugInfo {
    pub content_selector: String,
    pub removals: Vec<DebugRemoval>,
    pub errors: Vec<String>,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct DebugRemoval {
    pub step: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub selector: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub reason: Option<String>,
    pub text: String,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum WarningCode {
    MathNotSupported,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct Warning {
    pub code: WarningCode,
    pub message: String,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct MarkdownOutput {
    pub markdown: String,
    pub warnings: Vec<Warning>,
}

#[derive(Debug, thiserror::Error)]
pub enum Error {
    #[error("Invalid input: {0}")]
    InvalidInput(String),
    #[error("Could not serialize HTML: {0}")]
    Serialization(String),
}
