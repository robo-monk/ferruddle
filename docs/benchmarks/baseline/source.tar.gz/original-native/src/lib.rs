//! Readable HTML and Markdown extraction without network requests or script execution.
//!
//! Math conversion is not included. Detected math is reported through `warnings`.

mod callouts;
mod code;
mod constants;
#[doc(hidden)]
pub mod dom;
#[doc(hidden)]
pub mod extractors;
mod finalize;
mod footnotes;
mod images;
#[doc(hidden)]
pub mod markdown;
#[doc(hidden)]
pub mod math;
#[doc(hidden)]
pub mod metadata;
mod patterns;
mod pipeline;
mod removals;
#[doc(hidden)]
pub mod safety;
mod selection;
mod standardize;
mod types;
#[doc(hidden)]
pub mod utils;

pub use types::*;

/// Extract a page's main content. The URL supplies context for links and site rules.
///
/// ```
/// let result = defuddle::extract(
///     "<article><p>A useful article paragraph.</p></article>",
///     Some("https://example.com/article"),
///     &defuddle::Options { markdown: true, ..Default::default() },
/// ).unwrap();
/// assert!(result.content.contains("<p>"));
/// assert_eq!(result.content_markdown.as_deref(), Some("A useful article paragraph."));
/// ```
pub fn extract(html: &str, page_url: Option<&str>, options: &Options) -> Result<Extraction, Error> {
    pipeline::extract(html, page_url, options)
}

/// Convert HTML to Markdown without extracting its main content.
pub fn html_to_markdown(html: &str, page_url: Option<&str>) -> Result<MarkdownOutput, Error> {
    markdown::convert(html, page_url)
}
